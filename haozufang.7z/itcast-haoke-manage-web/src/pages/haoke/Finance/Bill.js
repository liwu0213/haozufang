import React, { PureComponent } from 'react';

class Bill extends React.Component{
    render(){
        return (
            <div>账单列表</div>
        );
    }
}

export default Bill;