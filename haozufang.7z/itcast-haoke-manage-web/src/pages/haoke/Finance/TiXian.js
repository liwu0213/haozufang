import React, { PureComponent } from 'react';

class TiXian extends React.Component{
    render(){
        return (
            <div>提现申请</div>
        );
    }
}

export default TiXian;