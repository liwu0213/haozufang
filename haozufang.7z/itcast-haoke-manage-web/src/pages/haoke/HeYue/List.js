import React, { PureComponent } from 'react';

class List extends React.Component{
    render(){
        return (
            <div>合约列表</div>
        );
    }
}

export default List;