import React, { PureComponent } from 'react';

class List extends React.Component{
    render(){
        return (
            <div>资讯列表</div>
        );
    }
}

export default List;