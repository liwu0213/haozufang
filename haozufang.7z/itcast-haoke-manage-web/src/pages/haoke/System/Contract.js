import React, { PureComponent } from 'react';

class Contract extends React.Component{
    render(){
        return (
            <div>合同列表</div>
        );
    }
}

export default Contract;