import React, { PureComponent } from 'react';

class Dict extends React.Component{
    render(){
        return (
            <div>字典列表</div>
        );
    }
}

export default Dict;