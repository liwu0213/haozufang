import React, { PureComponent } from 'react';

class Interface extends React.Component{
    render(){
        return (
            <div>房屋接口</div>
        );
    }
}

export default Interface;