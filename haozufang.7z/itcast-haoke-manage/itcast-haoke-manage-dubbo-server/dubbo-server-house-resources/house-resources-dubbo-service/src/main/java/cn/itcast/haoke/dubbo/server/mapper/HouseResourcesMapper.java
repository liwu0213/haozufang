package cn.itcast.haoke.dubbo.server.mapper;

import cn.itcast.haoke.dubbo.server.pojo.HouseResources;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface HouseResourcesMapper extends BaseMapper<HouseResources> {
}
