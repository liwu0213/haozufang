package cn.itcast.haoke.houseResources.request;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;


import java.util.function.Supplier;

public interface EntityConvert<T,E> {

    default E convertToEntity(Supplier<E> e){
        BeanUtil.copyProperties(this,e.get(), CopyOptions.create().setIgnoreNullValue(true));
        return e.get();
    }
}
