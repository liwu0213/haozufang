package cn.itcast.haoke.houseResources.response;

import lombok.Data;

@Data
public class PicUploadResult {

    private String uid;
    private String name;
    private String status;
    private String response;
}
